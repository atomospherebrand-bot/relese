import { SettingsForm } from "@/components/SettingsForm";

export default function Settings() {
  return <SettingsForm />;
}
