import { ExcelManager } from "@/components/ExcelManager";

export default function Excel() {
  return <ExcelManager />;
}
