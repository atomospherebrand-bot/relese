// client/src/App.tsx  (fragment — полный файл, готов к замене, если у вас схожая структура)
import React from "react";
import { Route, Switch } from "wouter";
import AppSidebar from "@/components/app-sidebar";

import Home from "@/pages/Home";
import Masters from "@/pages/Masters";
import Services from "@/pages/Services";
import Bookings from "@/pages/Bookings";
import Portfolio from "@/pages/Portfolio";
import BotMessagesPro from "@/pages/BotMessagesPro";
import ClientsPage from "@/pages/Clients";
import SchedulePage from "@/pages/Schedule";
import Certificates from "@/pages/Certificates";
import Excel from "@/pages/Excel";
import Settings from "@/pages/Settings";

export default function App() {
  return (
    <div className="flex min-h-screen bg-[#0f1218] text-white">
      <AppSidebar />
      <main className="flex-1">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/masters" component={Masters} />
          <Route path="/services" component={Services} />
          <Route path="/bookings" component={Bookings} />
          <Route path="/portfolio" component={Portfolio} />
          <Route path="/bot-messages" component={BotMessagesPro} />
          <Route path="/clients" component={ClientsPage} />
          <Route path="/schedule" component={SchedulePage} />
          <Route path="/certs" component={Certificates} />
          <Route path="/excel" component={Excel} />
          <Route path="/settings" component={Settings} />
        </Switch>
      </main>
    </div>
  );
}
