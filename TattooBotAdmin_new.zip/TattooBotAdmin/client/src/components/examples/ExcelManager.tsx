import { ExcelManager } from "../ExcelManager";

export default function ExcelManagerExample() {
  return (
    <div className="p-6">
      <ExcelManager />
    </div>
  );
}
