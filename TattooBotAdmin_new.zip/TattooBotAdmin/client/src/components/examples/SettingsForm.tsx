import { SettingsForm } from "../SettingsForm";

export default function SettingsFormExample() {
  return (
    <div className="p-6 max-w-4xl">
      <SettingsForm />
    </div>
  );
}
