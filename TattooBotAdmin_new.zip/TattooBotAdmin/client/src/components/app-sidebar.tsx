// client/src/components/app-sidebar.tsx
import * as React from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Calendar, FileSpreadsheet, Home, Image, MessageSquare, Settings, Users, BadgeCheck } from "lucide-react";

const menuItems = [
  { title: "Главная", url: "/", icon: Home },
  { title: "Мастера", url: "/masters", icon: Users },
  { title: "Услуги", url: "/services", icon: Settings },
  { title: "Записи", url: "/bookings", icon: Calendar },
  { title: "Портфолио", url: "/portfolio", icon: Image },
  { title: "Сообщения бота", url: "/bot-messages", icon: MessageSquare },
  { title: "Клиенты", url: "/clients", icon: Users },
  { title: "График", url: "/schedule", icon: Calendar },
  { title: "Сертификаты", url: "/certs", icon: BadgeCheck },
  { title: "Excel", url: "/excel", icon: FileSpreadsheet },
  { title: "Настройки", url: "/settings", icon: Settings },
];

export default function AppSidebar() {
  const [pathname] = useLocation();

  return (
    <aside className="w-[220px] shrink-0 border-r border-white/10 bg-[#14171f] text-white/90">
      <div className="px-4 py-4 font-semibold">Telegram Bot Admin</div>
      <nav className="grid gap-1 px-2 pb-4">
        {menuItems.map((item) => {
          const Icon = item.icon as any;
          const active = pathname === item.url || (item.url !== "/" && pathname.startsWith(item.url));
          return (
            <Link
              key={item.url}
              href={item.url}
              className={cn(
                "flex items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-white/10",
                active && "bg-white/10"
              )}
            >
              <Icon className="h-4 w-4 shrink-0" />
              <span className="truncate">{item.title}</span>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
