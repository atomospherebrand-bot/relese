-- Add imageUrl column to bot_messages table
ALTER TABLE "bot_messages" ADD COLUMN "image_url" text;
